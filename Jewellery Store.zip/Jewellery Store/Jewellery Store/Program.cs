using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JewelleryStore.DB.Models;
using JewelleryStore.DB.Services.Interfaces;
using JewelleryStore.DBContext;
using JewelleryStore.Estimation.Repositories.Interfaces;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;


namespace Jewellery_Store
{
    public class Program
    {

        public static void Main(string[] args)
        {
            //CreateHostBuilder(args).Build().Run();
            
            var host = CreateHostBuilder(args).Build();
            using (var scope = host.Services.CreateScope())
            { 
                var services = scope.ServiceProvider;
                var context = services.GetRequiredService<JewelleryStoreDatabaseContext>();
                DataGenerator.Initialize(services);
            }
            host.Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }

    #region DefaultUsersSetup
    public class DataGenerator
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new JewelleryStoreDatabaseContext(
                serviceProvider.GetRequiredService<DbContextOptions<JewelleryStoreDatabaseContext>>()))
            {
                // Esisting Details check
                if (context.UserDetails.Any())
                {
                    return;   // Data was already there
                }

                context.UserDetails.AddRange(
                     new Users
                     {
                         UserId = 1,
                         UserName = "Admin",
                         Password = "Admin",
                         UserType = Convert.ToString(UserTypes.PrivilegeUser)
                     },
                     new Users
                     {
                         UserId = 2,
                         UserName = "User1",
                         Password = "User1",
                         UserType = Convert.ToString(UserTypes.NormalUser)
                     });


                context.SaveChanges();
            }
        }
    }
    #endregion


}
