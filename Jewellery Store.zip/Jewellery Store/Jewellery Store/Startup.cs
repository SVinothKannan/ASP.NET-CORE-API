using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using JewelleryStore.DBContext;
using JewelleryStore.DB.Services.Interfaces;
using JewelleryStore.DB.Services;
using JewelleryStore.Estimation.Repositories.Interfaces;
using JewelleryStore.Estimation.Repositories;
using Microsoft.EntityFrameworkCore;
using System.Net;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System.IO;

namespace Jewellery_Store
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddCors(o => o.AddPolicy("LowCorsPolicy", builder =>
            {
                builder.AllowAnyOrigin()
                       .AllowAnyMethod()
                       .AllowAnyHeader();
            }));
            ConfigureTransientServices(services);
            ConfigureRepositories(services);
            ConfigureEntityFramework(services);
           
        }


        private static void ConfigureTransientServices(IServiceCollection services)
        {
            services.AddScoped<IEstimationPostService, EstimationPostService>();
            services.AddScoped<IUserPostService, UserPostService>();
        }

        private static void ConfigureRepositories(IServiceCollection services)
        {
            services.AddSingleton<IEstimationPostRepository, EstimationPostRepository>();
            services.AddSingleton<IUserRepository, UsersRepository>();
        }

        private void ConfigureEntityFramework(IServiceCollection services)
        {
            var databaseName = Configuration.GetValue<string>("EntityFramework:DatabaseName");

            services.AddDbContext<JewelleryStoreDatabaseContext>(options =>
                options.UseInMemoryDatabase(databaseName));
        }


        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            //app.UseWelcomePage();
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseConfigureExceptionHandler(Configuration);
            app.UseCors("LowCorsPolicy");
            app.UseRouting();
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }

    public static class ErrorHandler
    {
       
        public static void UseConfigureExceptionHandler(this IApplicationBuilder app, IConfiguration config)
        {
            app.UseExceptionHandler(appError =>
            {
                appError.Run(async context =>
                {
                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    context.Response.ContentType = "application/json";
                    var contextFeature = context.Features.Get<IExceptionHandlerFeature>();
                    if (contextFeature != null)
                    {
                        await context.Response.WriteAsync(new ErrorDetails()
                        {
                            StatusCode = context.Response.StatusCode,
                            Message = $"Something went wrong: {contextFeature.Error}"
                        }.ToString());

                    }
                });
            });
        }

    }
    public class ErrorDetails
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }


        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
}
