﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using JewelleryStore.DB.Models;
using JewelleryStore.DB.Services.Interfaces;
using JewelleryStore.Validation;
using Microsoft.Extensions.Logging;

namespace Jewellery_Store.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JewelleryServices_Controller : ControllerBase
    {
        private readonly IEstimationPostService _EstimationPostService;
        private readonly IUserPostService _UserPostService;

        public JewelleryServices_Controller(IEstimationPostService EstimationPostService,IUserPostService userPostService)
        {
            _EstimationPostService = EstimationPostService;
            _UserPostService = userPostService;
        }

        [HttpPost("PostEstimation/{EstimationPlanPost}")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Create([FromBody] EstimationPlan EstimationPlanPost)
        {
            if (EstimationPlanPost.IsValid(out IEnumerable<string> errors))
            {
                var result = await _EstimationPostService.Create(EstimationPlanPost);
                return Ok(result);
            }
            else
            {
                return BadRequest(errors);
            }
        }


        [HttpPut("PutEstimation/{EstimationPlan}")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Update([FromBody] EstimationPlan EstimationPlan)
        {
            if (EstimationPlan.IsValid(out IEnumerable<string> errors))
            {
                var result = await _EstimationPostService.Update(EstimationPlan);
                return Ok(result);
            }
            else
            {
                return BadRequest(errors);
            }
        }


        [HttpGet("GetEstimationById/{Id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult GetEstimationById(long Id)
        {
            var result = _EstimationPostService.Get(Id);

            return Ok(result);
        }

        [HttpGet("GetAllEstimations")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult GetAllEstimations()
        {
            var result =  _EstimationPostService.GetAll();

            return Ok(result);
        }




        [HttpPost("PostUsers/{Users}")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Create([FromBody] Users Users)
        {
            if (Users.IsValidUsers(out IEnumerable<string> errors))
            {
                var result = await _UserPostService.Create(Users);
                return Ok(result);
            }
            else
            {
                return BadRequest(errors);
            }
        }




        [HttpGet("GetAllUsers")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult GetAllUsers()
        {
            var result = _UserPostService.GetAll();

            return Ok(result);
        }

        [HttpPost("GetAuthorizedUser/{Objusers}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult GetAuthorizedUser([FromBody]Users Objusers)
        {
            var result =  _UserPostService.GetAuthorizedUsers(Objusers);

            return Ok(result);
        }


        [HttpGet("GetUsersById/{Id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult GetUsersById(long Id)
        {
            var result = _UserPostService.Get(Id);

            return Ok(result);
        }

        [HttpPut("Putusers/{Users}")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Update([FromBody] Users usersdetails)
        {
            if (usersdetails.IsValidUsers(out IEnumerable<string> errors))
            {
                var result = await _UserPostService.Update(usersdetails);
                return Ok(result);
            }
            else
            {
                return BadRequest(errors);
            }
        }


        [HttpDelete("DeleteUsers/{UserId}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> DeleteUser(long UserId)
        {
            if (UserId != 0)
            {
                var result = await _UserPostService.Delete(UserId);

                return Ok(result);
            }
            else
            {
                return BadRequest();
            }
        }

        [HttpDelete("delete/{Estimationid}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Delete(long Estimationid)
        {
            if (Estimationid!=0)
            {
                var result = await _EstimationPostService.Delete(Estimationid);

                return Ok(result);
            }
            else
            {
                return BadRequest();
            }
        }


    }
}
