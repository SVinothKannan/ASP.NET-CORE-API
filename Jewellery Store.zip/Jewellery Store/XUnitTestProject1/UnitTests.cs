using Jewellery_Store.Controllers;
using JewelleryStore.DB.Models;
using JewelleryStore.DB.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Threading.Tasks;
using Xunit;

namespace XUnitTestProject1
{
    public class UnitTests
    {
        public Mock<IEstimationPostService> mock = new Mock<IEstimationPostService>();
        public Mock<IUserPostService> mock2 = new Mock<IUserPostService>();
        private Jewellery_Store.Controllers.JewelleryServices_Controller JewelleryServices_Controller;

        //Get all registered Users Testcase
        [Fact]
        public void GetUsers()
        {
            JewelleryServices_Controller = new Jewellery_Store.Controllers.JewelleryServices_Controller(mock.Object,mock2.Object);

                var result = JewelleryServices_Controller.GetAllUsers();
                var okResult = result as OkObjectResult;
                Assert.NotNull(okResult);
                Assert.Equal(200, okResult.StatusCode); 
        }


        //Registered Users Validation TestCase
        [Fact]
        public void GetAuthorizedUser()
        {
            JewelleryServices_Controller = new Jewellery_Store.Controllers.JewelleryServices_Controller(mock.Object, mock2.Object);

            Users objusers = new Users();
            objusers.UserName = "Admin";
            objusers.Password = "Admin";
            objusers.UserType = "PrivilegeUser";
            var result = JewelleryServices_Controller.GetAuthorizedUser(objusers);
            var okResult = result as OkObjectResult;           
            Assert.NotNull(okResult);
        }


        //GetUsersById TestCase
        [Fact]
        public void GetUsersById()
        {
            JewelleryServices_Controller = new Jewellery_Store.Controllers.JewelleryServices_Controller(mock.Object, mock2.Object);
            long id = 1;
            var result = JewelleryServices_Controller.GetUsersById(id);
            var okResult = result as OkObjectResult;
            Assert.NotNull(okResult);
        }

        //DeleteUser TestCase
        [Fact]
        public void DeleteUser()
        {
            JewelleryServices_Controller = new Jewellery_Store.Controllers.JewelleryServices_Controller(mock.Object, mock2.Object);
            long id = 1;
            var result = JewelleryServices_Controller.DeleteUser(id);
            var okResult = result as Task<IActionResult>;
            Assert.NotNull(okResult);
        }


        //GetAllEstimations TestCase
        [Fact]
        public void GetAllEstimations()
        {
            JewelleryServices_Controller = new Jewellery_Store.Controllers.JewelleryServices_Controller(mock.Object, mock2.Object);
            var result = JewelleryServices_Controller.GetAllEstimations();
            var okResult = result as OkObjectResult;
            Assert.NotNull(okResult);
        }

        //GetEstimationById TestCase
        [Fact]
        public void GetEstimationById()
        {
            JewelleryServices_Controller = new Jewellery_Store.Controllers.JewelleryServices_Controller(mock.Object, mock2.Object);
            long id = 1;
            var result = JewelleryServices_Controller.GetEstimationById(id);
            var okResult = result as OkObjectResult;
            Assert.NotNull(okResult);
        }


    }
}
