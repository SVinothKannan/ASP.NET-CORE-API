﻿using JewelleryStore.DB.Models;
using Microsoft.EntityFrameworkCore;

namespace JewelleryStore.DBContext
{
    public class JewelleryStoreDatabaseContext:DbContext
    {
        public JewelleryStoreDatabaseContext(
            DbContextOptions<JewelleryStoreDatabaseContext> dbContextOptions)
            : base(dbContextOptions) { }

        public DbSet<EstimationPlan> EstimationPlans { get; set; }
        public DbSet<Users> UserDetails { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<EstimationPlan>()
                .HasKey(x => x.EstimationPlanId);

            modelBuilder.Entity<Users>()
                .HasKey(x => x.UserId);
        }
    }
}
