﻿using JewelleryStore.DB.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JewelleryStore.Estimation.Repositories.Interfaces
{
    public interface IUserRepository
    {
        Task<bool> Create(Users Users);
        Task<bool> Update(Users UserDetails);

        Users Get(long UserId);

        IOrderedQueryable<Users> GetAll();

        Task<bool> Delete(long UserId);

        Users GetAuthorizedUsers(Users UserDetails);
    }

    public enum UserTypes
    {
        PrivilegeUser = 1,
        NormalUser = 2
    }

}
