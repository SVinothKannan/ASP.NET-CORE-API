﻿using JewelleryStore.DB.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JewelleryStore.Estimation.Repositories.Interfaces
{
    public interface IEstimationPostRepository
    {
        Task<bool> Create(EstimationPlan EstimationPlanPost);

        Task<bool> Update(EstimationPlan EstimationPlanPost);

        EstimationPlan Get(long EstimationPlanId);

        IOrderedQueryable<EstimationPlan> GetAll();

        Task<bool> Delete(long EstimationPlanId);
    }
}
