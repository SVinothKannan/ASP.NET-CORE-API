﻿using System;
using System.Linq;
using JewelleryStore.DB.Models;
using JewelleryStore.Estimation.Repositories.Interfaces;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using JewelleryStore.DBContext;

namespace JewelleryStore.Estimation.Repositories
{
    public class UsersRepository : IUserRepository
    {
        private readonly IServiceScope _scope;
        private readonly JewelleryStoreDatabaseContext _databaseContext;

        public UsersRepository(IServiceProvider services)
        {
            _scope = services.CreateScope();

            _databaseContext = _scope.ServiceProvider.GetRequiredService<JewelleryStoreDatabaseContext>();
        }

        public async Task<bool> Create(Users Users)
        {
            var success = false;

            _databaseContext.UserDetails.Add(Users);

            var numberOfItemsCreated = await _databaseContext.SaveChangesAsync();

            if (numberOfItemsCreated == 1)
                success = true;

            return success;
        }


        public async Task<bool> Delete(long UserId)
        {
            var success = false;

            var existingUsers = Get(UserId);

            if (existingUsers != null)
            {
                _databaseContext.UserDetails.Remove(existingUsers);

                var numberOfItemsDeleted = await _databaseContext.SaveChangesAsync();

                if (numberOfItemsDeleted == 1)
                    success = true;
            }

            return success;
        }

        public Users Get(long UserId)
        {
            var result = _databaseContext.UserDetails
                           .Where(x => x.UserId == UserId)
                           .FirstOrDefault();

            return result;
        }

        public IOrderedQueryable<Users> GetAll()
        {
            var result = _databaseContext.UserDetails
                               .OrderByDescending(x => x.LastUpdatedDateTime);

            return result;
        }

        public Users GetAuthorizedUsers(Users UserDetails)
        {
            var result = _databaseContext.UserDetails
                          .Where(x => x.UserName == UserDetails.UserName).Where(x => x.Password == UserDetails.Password)
                          .Where(x=>x.UserType== UserDetails.UserType)
                          .FirstOrDefault();

            return result;
        }

        public async Task<bool> Update(Users UserDetails)
        {
            var success = false;

            var existingUsers = Get(UserDetails.UserId);

            if (existingUsers != null)
            {
                existingUsers.UserName = UserDetails.UserName;
                existingUsers.Password = UserDetails.Password;
                existingUsers.UserType = UserDetails.UserType;
                existingUsers.LastUpdatedDateTime = DateTime.Now;

                _databaseContext.UserDetails.Attach(existingUsers);

                var numberOfItemsUpdated = await _databaseContext.SaveChangesAsync();

                if (numberOfItemsUpdated == 1)
                    success = true;
            }

            return success;
        }
    }
}
