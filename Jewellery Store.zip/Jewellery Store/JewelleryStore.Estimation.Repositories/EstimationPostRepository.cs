﻿using System;
using System.Linq;
using JewelleryStore.DB.Models;
using JewelleryStore.Estimation.Repositories.Interfaces;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using JewelleryStore.DBContext;

namespace JewelleryStore.Estimation.Repositories
{
    public class EstimationPostRepository : IEstimationPostRepository
    {
        private readonly IServiceScope _scope;
        private readonly JewelleryStoreDatabaseContext _databaseContext;

        public EstimationPostRepository(IServiceProvider services)
        {
            _scope = services.CreateScope();

            _databaseContext = _scope.ServiceProvider.GetRequiredService<JewelleryStoreDatabaseContext>();
        }

        public async Task<bool> Create(EstimationPlan EstimationPlanPost)
        {
            var success = false;

            _databaseContext.EstimationPlans.Add(EstimationPlanPost);

            var numberOfItemsCreated = await _databaseContext.SaveChangesAsync();

            if (numberOfItemsCreated == 1)
                success = true;

            return success;
        }

        public async Task<bool> Update(EstimationPlan EstimationPlanPost)
        {
            var success = false;

            var existingEstimationPlan= Get(EstimationPlanPost.EstimationPlanId);

            if (existingEstimationPlan != null)
            {
                existingEstimationPlan.EstimationPlanId = EstimationPlanPost.EstimationPlanId;
                existingEstimationPlan.GoldPrice = EstimationPlanPost.GoldPrice;
                existingEstimationPlan.Weight = EstimationPlanPost.Weight;
                existingEstimationPlan.TotalPrice = EstimationPlanPost.TotalPrice;
                existingEstimationPlan.discount = EstimationPlanPost.discount;
                existingEstimationPlan.LastUpdatedDateTimeUtc = EstimationPlanPost.LastUpdatedDateTimeUtc;

                _databaseContext.EstimationPlans.Attach(existingEstimationPlan);

                var numberOfItemsUpdated = await _databaseContext.SaveChangesAsync();

                if (numberOfItemsUpdated == 1)
                    success = true;
            }

            return success;
        }



        public async Task<bool> Delete(long EstimationPlanId)
        {
            var success = false;

            var existingBlogPost = Get(EstimationPlanId);

            if (existingBlogPost != null)
            {
                _databaseContext.EstimationPlans.Remove(existingBlogPost);

                var numberOfItemsDeleted = await _databaseContext.SaveChangesAsync();

                if (numberOfItemsDeleted == 1)
                    success = true;
            }

            return success;
        }

        public EstimationPlan Get(long EstimationPlanId)
        {
            var result = _databaseContext.EstimationPlans
                           .Where(x => x.EstimationPlanId == EstimationPlanId)
                           .FirstOrDefault();

            return result;
        }

        public IOrderedQueryable<EstimationPlan> GetAll()
        {
            var result = _databaseContext.EstimationPlans
                               .OrderByDescending(x => x.LastUpdatedDateTimeUtc);

            return result;
        }

        
    }
}
