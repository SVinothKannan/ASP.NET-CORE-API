﻿using FluentValidation;
using JewelleryStore.DB.Models;
using FluentValidation.Results;

namespace JewelleryStore.Validation
{
    public class UsersValidator : AbstractValidator<Users>
    {
        public UsersValidator()
        {
            RuleFor(m => m.UserName).NotNull().WithMessage("Please Enter a UserName.");

            RuleFor(m => m.Password).NotNull().WithMessage("Please Enter a Password.");

            RuleFor(m => m.UserType).NotNull().WithMessage("Please select a UserType.");
        }

        protected override bool PreValidate(ValidationContext<Users> context, ValidationResult result)
        {
            if (context.InstanceToValidate == null)
            {
                result.Errors.Add(new ValidationFailure("", "Please submit a non-null model."));

                return false;
            }
            return true;
        }
    }
}
