﻿using System;
using System.Collections.Generic;
using FluentValidation.Results;
using JewelleryStore.DB.Models;

namespace JewelleryStore.Validation
{
    public static class ValidationExtensions
    {
        public static bool IsValid(this EstimationPlan blogPost, out IEnumerable<string> errors)
        {
            var validator = new EstimationPlanValidator();

            var validationResult = validator.Validate(blogPost);

            errors = AggregateErrors(validationResult);

            return validationResult.IsValid;
        }

        private static List<string> AggregateErrors(ValidationResult validationResult)
        {
            var errors = new List<string>();

            if (!validationResult.IsValid)
                foreach (var error in validationResult.Errors)
                    errors.Add(error.ErrorMessage);

            return errors;
        }


        public static bool IsValidUsers(this Users userpost, out IEnumerable<string> errors)
        {
            var validator = new UsersValidator();

            var validationResult = validator.Validate(userpost);

            errors = AggregateErrors(validationResult);

            return validationResult.IsValid;
        }

       
    }
}
