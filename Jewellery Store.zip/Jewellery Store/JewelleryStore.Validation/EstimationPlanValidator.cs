﻿using FluentValidation;
using FluentValidation.Results;
using JewelleryStore.DB.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace JewelleryStore.Validation
{
    public class EstimationPlanValidator : AbstractValidator<EstimationPlan>
    {
        public EstimationPlanValidator()
        {
            RuleFor(m => m.GoldPrice).NotNull().WithMessage("Please Enter a GoldPrice.");

            RuleFor(m => m.Weight).NotNull().WithMessage("Please Enter a Weight.");

            RuleFor(m => m.TotalPrice).NotNull().WithMessage("Please Calculate the details.");
        }

        protected override bool PreValidate(ValidationContext<EstimationPlan> context, ValidationResult result)
        {
            if (context.InstanceToValidate == null)
            {
                result.Errors.Add(new ValidationFailure("", "Please submit a non-null model."));

                return false;
            }
            return true;
        }
    }
}
