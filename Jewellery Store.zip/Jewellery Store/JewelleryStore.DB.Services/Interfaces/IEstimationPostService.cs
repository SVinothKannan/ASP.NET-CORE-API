﻿using JewelleryStore.DB.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JewelleryStore.DB.Services.Interfaces
{
    public interface IEstimationPostService
    {
        Task<EstimationPlan> Create(EstimationPlan blogPost);

        Task<EstimationPlan> Update(EstimationPlan blogPost);

        EstimationPlan Get(long EstimationPlanId);

        IOrderedQueryable<EstimationPlan> GetAll();

        Task<bool> Delete(long EstimationPlanId);
    }
}
