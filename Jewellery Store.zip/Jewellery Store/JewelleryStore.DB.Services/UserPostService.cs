﻿using JewelleryStore.DB.Models;
using JewelleryStore.DB.Services.Interfaces;
using JewelleryStore.Estimation.Repositories.Interfaces;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace JewelleryStore.DB.Services
{
    public class UserPostService : IUserPostService
    {
        private readonly IUserRepository _repository;

        public UserPostService(IUserRepository repository)
        {
            _repository = repository;
        }
        public async Task<Users> Create(Users Users)
        {

            var success = await _repository.Create(Users);

            if (success)
                return Users;
            else
                return null;
        }
        public async Task<bool> Delete(long UserId)
        {
            var success = await _repository.Delete(UserId);

            return success;
        }

        public Users Get(long UserId)
        {
            var result = _repository.Get(UserId);

            return result;
        }

        public IOrderedQueryable<Users> GetAll()
        {
            var result = _repository.GetAll();

            return result;
        }

        public async Task<Users> Update(Users UserDetails)
        {
            UserDetails.LastUpdatedDateTime = DateTime.Now;

            var success = await _repository.Update(UserDetails);

            if (success)
                return UserDetails;
            else
                return null;
        }

        public  Users GetAuthorizedUsers(Users UserDetails)
        {
            var success = _repository.GetAuthorizedUsers(UserDetails);

            if (success!=null)
                return UserDetails;
            else
                return null;
        }

    }
}
