﻿using JewelleryStore.DB.Models;
using JewelleryStore.DB.Services.Interfaces;
using JewelleryStore.Estimation.Repositories.Interfaces;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace JewelleryStore.DB.Services
{
    public class EstimationPostService:IEstimationPostService
    {
        private readonly IEstimationPostRepository _repository;

        public EstimationPostService(IEstimationPostRepository repository)
        {
            _repository = repository;
        }

        public async Task<EstimationPlan> Create(EstimationPlan EstimationPlanPost)
        {
            EstimationPlanPost.LastUpdatedDateTimeUtc = DateTime.UtcNow;

            var success = await _repository.Create(EstimationPlanPost);

            if (success)
                return EstimationPlanPost;
            else
                return null;
        }

        public async Task<EstimationPlan> Update(EstimationPlan EstimationPlanPost)
        {
            EstimationPlanPost.LastUpdatedDateTimeUtc = DateTime.UtcNow;

            var success = await _repository.Update(EstimationPlanPost);

            if (success)
                return EstimationPlanPost;
            else
                return null;
        }

        public EstimationPlan Get(long EstimationPlanId)
        {
            var result = _repository.Get(EstimationPlanId);

            return result;
        }

        public IOrderedQueryable<EstimationPlan> GetAll()
        {
            var result = _repository.GetAll();

            return result;
        }

        public async Task<bool> Delete(long EstimationPlanId)
        {
            var success = await _repository.Delete(EstimationPlanId);

            return success;
        }
    }
}
