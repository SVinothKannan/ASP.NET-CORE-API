﻿using System;
using System.Collections.Generic;

namespace JewelleryStore.DB.Models
{
    public class EstimationPlan
    {
        public long EstimationPlanId { get; set; }
        public decimal GoldPrice { get; set; }
        public decimal Weight { get; set; }
        public decimal TotalPrice { get; set; }
        public long discount { get; set; }
        public DateTime LastUpdatedDateTimeUtc { get; set; } = DateTime.Now;

    }
}
